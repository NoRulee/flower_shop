import 'package:flower_store/app.dart';
import 'package:flutter/material.dart';

void main() {
  runApp(const MainApp());
}
